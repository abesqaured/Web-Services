package gfakefood

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class SavedorderControllerSpec extends Specification implements ControllerUnitTest<SavedorderController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
