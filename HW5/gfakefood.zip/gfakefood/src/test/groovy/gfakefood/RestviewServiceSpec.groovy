package gfakefood

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class RestviewServiceSpec extends Specification implements ServiceUnitTest<RestviewService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
