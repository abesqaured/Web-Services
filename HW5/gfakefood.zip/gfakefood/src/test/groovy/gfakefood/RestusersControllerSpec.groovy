package gfakefood

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class RestusersControllerSpec extends Specification implements ControllerUnitTest<RestusersController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
