package gfakefood

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class UsersSpec extends Specification implements DomainUnitTest<Users> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
