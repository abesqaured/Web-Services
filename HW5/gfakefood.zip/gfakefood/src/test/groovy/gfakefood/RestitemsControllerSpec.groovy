package gfakefood

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class RestitemsControllerSpec extends Specification implements ControllerUnitTest<RestitemsController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
