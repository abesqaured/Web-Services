package gfakefood

import grails.gorm.transactions.Transactional

@Transactional
class RestviewService {

    def serviceMethod() {

    }
}
